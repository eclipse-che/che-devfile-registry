package org.acme.sqs;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeSqsResourcesIT extends SqsResourcesTest {
    // Runs the same tests as the parent class
}
