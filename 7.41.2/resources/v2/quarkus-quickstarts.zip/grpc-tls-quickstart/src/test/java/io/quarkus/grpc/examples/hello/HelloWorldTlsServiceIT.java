package io.quarkus.grpc.examples.hello;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
class HelloWorldTlsServiceIT extends HelloWorldTlsEndpointTest {

}