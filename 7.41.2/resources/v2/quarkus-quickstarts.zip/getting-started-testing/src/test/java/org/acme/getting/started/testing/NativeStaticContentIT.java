package org.acme.getting.started.testing;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeStaticContentIT extends StaticContentTest {

    // Execute the same tests but in native mode.
}