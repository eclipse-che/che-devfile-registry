package org.acme.infinispan.client;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeInfinispanGreetingResourceIT extends InfinispanGreetingResourceTest {
}
