package org.acme.reactive.crud;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
class FruitResourceIT extends FruitResourceTest {

}