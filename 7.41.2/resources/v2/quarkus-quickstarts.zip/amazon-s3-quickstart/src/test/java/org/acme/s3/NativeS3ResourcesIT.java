package org.acme.s3;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeS3ResourcesIT extends S3ResourcesTest {
    // Runs the same tests as the parent class
}
