package org.acme.ses;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeSesResourcesIT extends SesResourcesTest {
    // Runs the same tests as the parent class
}
