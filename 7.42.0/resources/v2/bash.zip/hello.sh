#!/bin/bash

function sayHello() {
    echo "Hello world!"
}
