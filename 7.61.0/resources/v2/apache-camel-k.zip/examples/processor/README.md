# Processors Camel K examples

Find useful examples about how to include a `Processor` in a Camel K integration.