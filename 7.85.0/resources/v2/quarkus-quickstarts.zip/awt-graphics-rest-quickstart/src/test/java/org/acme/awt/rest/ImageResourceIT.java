package org.acme.awt.rest;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class ImageResourceIT extends ImageResourceTest {
    // Execute the same tests but in native mode.
}
