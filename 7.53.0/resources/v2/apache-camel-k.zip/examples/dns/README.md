# DNS Camel K examples

Find useful examples about how to use DNS in a Camel K integration.