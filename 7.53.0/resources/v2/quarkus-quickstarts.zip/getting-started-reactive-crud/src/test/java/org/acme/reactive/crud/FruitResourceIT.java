package org.acme.reactive.crud;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class FruitResourceIT extends FruitResourceTest {

}