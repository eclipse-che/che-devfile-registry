/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Red Hat, Inc. All rights reserved.
 *  Licensed under the MIT License. See LICENSE in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
#include <iostream>

using std::cout;
using std::endl;

int main()
{
    cout << "Hello, World!" << endl;
    return 0;
}
