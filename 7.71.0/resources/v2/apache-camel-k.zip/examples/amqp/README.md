# AMQP Camel K examples

Find useful examples about how to use AMQP in a Camel K integration.

You may find useful instructions [how to install a JMS/AMQP Broker on Kubernetes](./artemis/) for demo purposes.