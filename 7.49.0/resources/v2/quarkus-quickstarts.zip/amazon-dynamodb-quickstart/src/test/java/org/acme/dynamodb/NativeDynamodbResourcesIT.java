package org.acme.dynamodb;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeDynamodbResourcesIT extends DynamodbResourcesTest {
    // Runs the same tests as the parent class
}
