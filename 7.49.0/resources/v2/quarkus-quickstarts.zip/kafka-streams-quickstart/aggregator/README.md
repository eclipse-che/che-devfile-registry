Quarkus guide: https://quarkus.io/guides/kafka-streams
