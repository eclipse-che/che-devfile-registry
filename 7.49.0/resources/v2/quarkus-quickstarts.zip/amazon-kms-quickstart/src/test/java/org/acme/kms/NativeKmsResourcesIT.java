package org.acme.kms;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeKmsResourcesIT extends KmsResourcesTest {
    // Runs the same tests as the parent class
}
