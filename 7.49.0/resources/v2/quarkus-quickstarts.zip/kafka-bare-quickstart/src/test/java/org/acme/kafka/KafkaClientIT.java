package org.acme.kafka;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
class KafkaClientIT extends KafkaClientTests {

}