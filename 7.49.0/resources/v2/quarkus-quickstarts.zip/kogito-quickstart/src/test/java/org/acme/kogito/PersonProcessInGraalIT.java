package org.acme.kogito;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class PersonProcessInGraalIT extends PersonProcessTest {

}
