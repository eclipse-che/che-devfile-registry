package org.acme.jms;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class PriceTestIT extends PriceTest {
}
