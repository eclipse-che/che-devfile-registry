# Polyglot Camel K examples

Run an integration using different Camel DSL languages.

```
$ kamel run --name polyglot routes.xml beans.groovy JavaRoute.java
```