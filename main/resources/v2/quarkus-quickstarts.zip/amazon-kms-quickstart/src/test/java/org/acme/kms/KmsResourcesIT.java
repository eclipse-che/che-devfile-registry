package org.acme.kms;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class KmsResourcesIT extends KmsResourcesTest {
    // Runs the same tests as the parent class
}
