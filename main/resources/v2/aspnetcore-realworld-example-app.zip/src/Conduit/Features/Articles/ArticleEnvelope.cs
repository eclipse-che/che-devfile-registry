using Conduit.Domain;

namespace Conduit.Features.Articles
{
    public record ArticleEnvelope(Article Article);
}
