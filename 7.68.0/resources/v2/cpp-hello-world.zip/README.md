# cpp-hello-world

Hello World Program. It prints the "Hello, World!" string on the monitor.
